#pragma once

bool bump_mouse_x11(int dx, int dy);
