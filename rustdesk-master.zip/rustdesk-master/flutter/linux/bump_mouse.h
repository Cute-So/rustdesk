#pragma once

bool bump_mouse(int dx, int dy);
