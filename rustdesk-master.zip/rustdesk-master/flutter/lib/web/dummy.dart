Future<void> webselectFiles({required bool is_folder}) async {
  throw UnimplementedError("webselectFiles");
}

Future<void> webSendLocalFiles(
    {required int handleIndex,
    required int actId,
    required String path,
    required String to,
    required int fileNum,
    required bool includeHidden,
    required bool isRemote}) {
  throw UnimplementedError("webSendLocalFiles");
}
