mod macos_impl;

pub mod keycodes;
pub use self::macos_impl::{Enigo, ENIGO_INPUT_EXTRA_VALUE};
